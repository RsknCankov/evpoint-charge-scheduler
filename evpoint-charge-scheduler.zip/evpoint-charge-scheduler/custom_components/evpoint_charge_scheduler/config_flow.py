"""Config flow for EVPoint Charge Scheduler."""
from __future__ import annotations

from typing import Any

import voluptuous as vol
from homeassistant import config_entries
from homeassistant.core import callback
from homeassistant.helpers import selector

from .const import (
    CONF_APARTMENT_CURRENT_SENSOR,
    CONF_BATTERY_CAPACITY,
    CONF_CHARGER_SWITCH,
    CONF_CHARGING_LOSS,
    CONF_HEADROOM,
    CONF_MAX_CURRENT,
    CONF_MIN_CURRENT,
    CONF_NIGHT_END,
    CONF_NIGHT_START,
    CONF_NIGHT_TARIFF_VALUE,
    CONF_OCPP_SET_RATE_FIELD,
    CONF_OCPP_SET_RATE_SERVICE,
    CONF_OCPP_SET_RATE_TARGET,
    CONF_PHASES,
    CONF_SAFETY_MARGIN_HOURS,
    CONF_SOC_SENSOR,
    CONF_TARIFF_SENSOR,
    CONF_TOTAL_LIMIT,
    CONF_VOLTAGE,
    DEFAULT_BATTERY_CAPACITY,
    DEFAULT_CHARGING_LOSS,
    DEFAULT_HEADROOM,
    DEFAULT_MAX_CURRENT,
    DEFAULT_MIN_CURRENT,
    DEFAULT_NIGHT_END,
    DEFAULT_NIGHT_START,
    DEFAULT_NIGHT_TARIFF_VALUE,
    DEFAULT_OCPP_FIELD,
    DEFAULT_OCPP_SERVICE,
    DEFAULT_PHASES,
    DEFAULT_SAFETY_MARGIN_HOURS,
    DEFAULT_TOTAL_LIMIT,
    DEFAULT_VOLTAGE,
    DOMAIN,
)


def _entity_selector(domain: str | list[str] | None = None):
    cfg: dict[str, Any] = {}
    if domain:
        cfg["domain"] = domain
    return selector.EntitySelector(selector.EntitySelectorConfig(**cfg))


def _build_schema(defaults: dict[str, Any] | None = None) -> vol.Schema:
    d = defaults or {}
    return vol.Schema(
        {
            # External entities - all optional. The integration degrades
            # gracefully when any of these are left blank:
            #   - No tariff sensor       -> derive night/day from configured times
            #   - No apartment sensor    -> no load balancing (full charger limit available)
            #   - No SoC sensor          -> manual number entity is created instead
            #   - No charger switch      -> integration only sets the current limit
            #   - No OCPP service        -> "advisory mode": decisions exposed via sensors
            vol.Optional(CONF_TARIFF_SENSOR, default=d.get(CONF_TARIFF_SENSOR, vol.UNDEFINED)): _entity_selector("sensor"),
            vol.Optional(CONF_NIGHT_TARIFF_VALUE, default=d.get(CONF_NIGHT_TARIFF_VALUE, DEFAULT_NIGHT_TARIFF_VALUE)): str,
            vol.Optional(CONF_APARTMENT_CURRENT_SENSOR, default=d.get(CONF_APARTMENT_CURRENT_SENSOR, vol.UNDEFINED)): _entity_selector("sensor"),
            vol.Optional(CONF_SOC_SENSOR, default=d.get(CONF_SOC_SENSOR, vol.UNDEFINED)): _entity_selector("sensor"),
            vol.Optional(CONF_CHARGER_SWITCH, default=d.get(CONF_CHARGER_SWITCH, vol.UNDEFINED)): _entity_selector("switch"),

            # OCPP service to set current limit - optional
            vol.Optional(CONF_OCPP_SET_RATE_SERVICE, default=d.get(CONF_OCPP_SET_RATE_SERVICE, DEFAULT_OCPP_SERVICE)): str,
            vol.Optional(CONF_OCPP_SET_RATE_FIELD, default=d.get(CONF_OCPP_SET_RATE_FIELD, DEFAULT_OCPP_FIELD)): str,
            vol.Optional(CONF_OCPP_SET_RATE_TARGET, default=d.get(CONF_OCPP_SET_RATE_TARGET, vol.UNDEFINED)): _entity_selector(),

            # Car / charger spec
            vol.Required(CONF_BATTERY_CAPACITY, default=d.get(CONF_BATTERY_CAPACITY, DEFAULT_BATTERY_CAPACITY)): vol.Coerce(float),
            vol.Required(CONF_CHARGING_LOSS, default=d.get(CONF_CHARGING_LOSS, DEFAULT_CHARGING_LOSS)): vol.Coerce(float),
            vol.Required(CONF_VOLTAGE, default=d.get(CONF_VOLTAGE, DEFAULT_VOLTAGE)): vol.Coerce(int),
            vol.Required(CONF_PHASES, default=d.get(CONF_PHASES, DEFAULT_PHASES)): vol.In([1, 3]),
            vol.Required(CONF_MIN_CURRENT, default=d.get(CONF_MIN_CURRENT, DEFAULT_MIN_CURRENT)): vol.Coerce(int),
            vol.Required(CONF_MAX_CURRENT, default=d.get(CONF_MAX_CURRENT, DEFAULT_MAX_CURRENT)): vol.Coerce(int),

            # Load balancing
            vol.Required(CONF_TOTAL_LIMIT, default=d.get(CONF_TOTAL_LIMIT, DEFAULT_TOTAL_LIMIT)): vol.Coerce(int),
            vol.Required(CONF_HEADROOM, default=d.get(CONF_HEADROOM, DEFAULT_HEADROOM)): vol.Coerce(int),

            # Tariff schedule
            vol.Required(CONF_NIGHT_START, default=d.get(CONF_NIGHT_START, DEFAULT_NIGHT_START)): str,
            vol.Required(CONF_NIGHT_END, default=d.get(CONF_NIGHT_END, DEFAULT_NIGHT_END)): str,
            vol.Required(CONF_SAFETY_MARGIN_HOURS, default=d.get(CONF_SAFETY_MARGIN_HOURS, DEFAULT_SAFETY_MARGIN_HOURS)): vol.Coerce(float),
        }
    )


class ConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    """Handle a config flow for EVPoint Charge Scheduler."""

    VERSION = 1

    async def async_step_user(self, user_input: dict[str, Any] | None = None):
        if user_input is not None:
            await self.async_set_unique_id(DOMAIN)
            self._abort_if_unique_id_configured()
            return self.async_create_entry(title="EVPoint Charge Scheduler", data=user_input)

        return self.async_show_form(step_id="user", data_schema=_build_schema())

    @staticmethod
    @callback
    def async_get_options_flow(config_entry):
        return OptionsFlow(config_entry)


class OptionsFlow(config_entries.OptionsFlow):
    """Allow editing config after setup."""

    def __init__(self, config_entry) -> None:
        self.config_entry = config_entry

    async def async_step_init(self, user_input: dict[str, Any] | None = None):
        if user_input is not None:
            return self.async_create_entry(title="", data=user_input)

        # Merge data + options so the user sees their current values
        defaults = {**self.config_entry.data, **self.config_entry.options}
        return self.async_show_form(step_id="init", data_schema=_build_schema(defaults))
